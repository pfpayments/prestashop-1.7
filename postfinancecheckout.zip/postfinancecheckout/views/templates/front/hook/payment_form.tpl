{*
 * PostFinance Checkout Prestashop
 *
 * This Prestashop module enables to process payments with PostFinance Checkout (https://postfinance.ch/en/business/products/e-commerce/postfinance-checkout-all-in-one.html).
 *
 * @author customweb GmbH (http://www.customweb.com/)
 * @copyright 2017 - 2025 customweb GmbH
 * @license http://www.apache.org/licenses/LICENSE-2.0 Apache Software License (ASL 2.0)
 *}
<form action="{$orderUrl|escape:'html'}" class="postfinancecheckout-payment-form" data-method-id="{$methodId|escape:'html':'UTF-8'}">
	<div id="postfinancecheckout-{$methodId|escape:'html':'UTF-8'}">
		<input type="hidden" id="postfinancecheckout-iframe-possible-{$methodId|escape:'html':'UTF-8'}" name="postfinancecheckout-iframe-possible-{$methodId|escape:'html':'UTF-8'}" value="false" />
		{if !$isPaymentPageCheckout}
			<div id="postfinancecheckout-loader-{$methodId|escape:'html':'UTF-8'}" class="postfinancecheckout-loader"></div>
		{/if}
	</div>
</form>
